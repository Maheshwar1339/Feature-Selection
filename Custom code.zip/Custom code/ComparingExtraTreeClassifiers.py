import warnings
warnings.filterwarnings("ignore")
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import numpy as np
import pylab
import time
import matplotlib.pyplot as plt
#import plotly.plotly as py
from sklearn.decomposition import PCA
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import roc_auc_score

start =time.time()
#reading the data
data1=pd.read_excel('WithoutETC.xlsx')
data2=pd.read_excel('EliminatingLineamentDensityETC.xlsx')
data3=pd.read_excel('EliminatingLineamentDensityAndG&GETC.xlsx')
data4=pd.read_excel('EliminatingLineamentDensityAndG&GAndDRETC.xlsx')

d1 = data1.ix[:,0:7]
t1 = data1.ix[:,7:]

d2 = data2.ix[:,0:6]
t2 = data2.ix[:,6:]

d3 = data3.ix[:,0:5]
t3 = data3.ix[:,5:]

d4 = data4.ix[:,0:4]
t4 = data4.ix[:,4:]


model3 = DecisionTreeClassifier()
x3=model3.fit(d3, t3)

# fit a Decision Tree Classifier model to the data
model1 = DecisionTreeClassifier()
x1=model1.fit(d1, t1)

model2 = DecisionTreeClassifier()
x2=model2.fit(d2, t2)


model4 = DecisionTreeClassifier()
x4=model4.fit(d4, t4)

# make predictions
expected=[]
for i in t4['Class']:
    expected.append(i)

predicted = model4.predict(d4)

predict_probe3=model3.predict_proba(d3)
predict_probe3=predict_probe3[:,1]

# summarize the fit of the model
#print(metrics.classification_report(expected, predicted))
#print("\nConfusion Matrix=\n",metrics.confusion_matrix(expected, predicted))
#print("\nAccuracy=",model4.score(d4,t4))
#Accuracy=model4.score(d4,t4)

predict_probe1=model1.predict_proba(d1)
predict_probe1=predict_probe1[:,1]

predict_probe2=model2.predict_proba(d2)
predict_probe2=predict_probe2[:,1]


predict_probe4=model4.predict_proba(d4)
predict_probe4=predict_probe4[:,1]

#Finding Area underROC, FPR, TPR
dc_auc3=roc_auc_score(t3,predict_probe3)
fpr3,tpr3,_=roc_curve(t3,predict_probe3)



dc_auc1=roc_auc_score(t1,predict_probe1)
fpr1,tpr1,_=roc_curve(t1,predict_probe1)

dc_auc2=roc_auc_score(t2,predict_probe2)
fpr2,tpr2,_=roc_curve(t2,predict_probe2)


dc_auc4=roc_auc_score(t4,predict_probe4)
fpr4,tpr4,_=roc_curve(t4,predict_probe4)


end=time.time()
print("runtime=")
print((end-start))
#Generating ROC
plt.rcParams["font.family"] = "Times New Roman"
plt.plot(fpr1,tpr1,linestyle="--",color="black",label='Without eliminating any feature\n(AUROC =%0.3f)'% dc_auc1)
plt.plot(fpr2,tpr2,linestyle="--",color="red",label='Eliminating Lineament Density\n(AUROC =%0.3f)'% dc_auc2)
plt.plot(fpr3,tpr3,linestyle="--",color="blue",label='EliminatingLineament Density and\nGeology & geomorphology\n(AUROC =%0.3f)'% dc_auc3)
plt.plot(fpr4,tpr4,linestyle="--",color="orange",label='EliminatingLineament Density and\nGeology & geomorphology\nDistance to Road\n(AUROC =%0.3f)'% dc_auc4)
plt.title('ROC plot for Extra Tree Classifier',fontsize=12)
plt.xlabel('False Positive Rate',fontsize=12)
plt.ylabel('True Positive Rate',fontsize=12)
plt.legend(prop={'size': 12})
plt.show()


