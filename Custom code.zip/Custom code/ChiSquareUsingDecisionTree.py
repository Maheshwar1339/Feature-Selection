import warnings
warnings.filterwarnings("ignore")
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import numpy as np
import pylab
import matplotlib.pyplot as plt
#import plotly.plotly as py
from sklearn.decomposition import PCA
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import roc_auc_score

#reading the data
data=pd.read_excel('LandSlide_Data_ChiSquare.xlsx')

d = data.ix[:,0:5]

t = data.ix[:,5:]

# fit a Decision Tree Classifier model to the data
model = DecisionTreeClassifier()
x=model.fit(d, t)

predict_probe=model.predict_proba(d)
predict_probe=predict_probe[:,1]

#Finding Area underROC, FPR, TPR
dc_auc=roc_auc_score(t,predict_probe)
fpr,tpr,_=roc_curve(t,predict_probe)


# make predictions
expected=[]
for i in t['Class']:
    expected.append(i)

predicted = model.predict(d)

# summarize the fit of the model
print(metrics.classification_report(expected, predicted))
print("\nConfusion Matrix=\n",metrics.confusion_matrix(expected, predicted))
print("\nAccuracy=",model.score(d,t))
Accuracy=model.score(d,t)

#Generating ROC
plt.rcParams["font.family"] = "Times New Roman"
plt.plot(fpr,tpr,linestyle="--",color="black",label='eliminating geology & geomorphology and\nSlope\n(AUROC =%0.3f)'% dc_auc)
plt.title('(b) ROC plot for Chi square',fontsize=12)
plt.xlabel('False Positive Rate',fontsize=12)
plt.ylabel('True Positive Rate',fontsize=12)
plt.legend(prop={'size': 12})
plt.show()


#Generating Graph 
fig=plt.figure()
fig.suptitle('Accuracy='+ str(round(Accuracy,4)*100)+'%\n', fontsize=16)
plt1=fig.add_subplot(121)

#Applying PCA for Dimension Reduction
pca = PCA(n_components=2).fit(d)
pca_2d = pca.transform(d)


for i in range(0, pca_2d.shape[0]):

    if expected[i] == 0:
        c1 = plt1.scatter(pca_2d[i,0],pca_2d[i,1],c='r',marker='o', s=100)
    elif expected[i] == 1:
        c2 = plt1.scatter(pca_2d[i,0],pca_2d[i,1],c='b',marker='o', s=100)
           
plt1.legend([c1, c2], ['Debris Slide', 'Rock Slide'], loc=2,prop={'size': 14} )
plt1.set_title('Before Applying Decision Tree Classifier', fontsize=16)



plt2=fig.add_subplot(122)
pca = PCA(n_components=2).fit(d)
pca_2d = pca.transform(d)
for i in range(0, pca_2d.shape[0]):

    if predicted[i] == 0:
        c1 = plt2.scatter(pca_2d[i,0],pca_2d[i,1],c='r',marker='o' ,s=100)
    elif predicted[i] == 1:
        c2 = plt2.scatter(pca_2d[i,0],pca_2d[i,1],c='b',marker='o', s=100)
           
plt2.legend([c1, c2], ['Debris Slide', 'Rock Slide'], loc=2,prop={'size': 14})
plt2.set_title('After Applying Decision Tree Classifier',fontsize=16)
plt.tight_layout()
plt.show()

